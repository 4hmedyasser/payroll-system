package eeps;

public class EEPS {

    public static void main(String[] args) {
    
    
    passwordError as = new passwordError();
    as.setVisible(true);


    }
    
}
